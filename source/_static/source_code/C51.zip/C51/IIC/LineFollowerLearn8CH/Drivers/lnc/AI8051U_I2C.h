#ifndef __AI8051U_I2C_H__
#define __AI8051U_I2C_H__

#include "type.h"

void i2c_init(void);
void i2c_write_data(uint8_t dev_addr, uint8_t reg, uint8_t* _pdata, uint16_t len);
void i2c_read_data(uint8_t dev_addr, uint8_t reg, uint8_t* _pdata, uint16_t len);

#endif

