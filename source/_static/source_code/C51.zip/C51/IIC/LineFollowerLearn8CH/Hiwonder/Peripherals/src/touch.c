#include "touch.h"
#include "AI8051U.h"

void touch_init()
{
    P0M0 &= ~0x10; 
	P0M1 |= 0x10; 
}

uint8_t get_touch_state()
{
	uint8_t state;
	state = (P0 & 0x10) >> 4;
	return state;
}