#ifndef __WONDER_MV_H_
#define __WONDER_MV_H_

#include "type.h"

#define WONDERMV_ADDR  0x32
#define COLOR_REG  	   0x00
#define FACE_REG  	   0x10
#define TAG_REG  	   0x20
#define OBJECT_REG     0x30

typedef struct
{
	uint16_t w;
	uint16_t h;
	uint16_t x;
	uint16_t y;
}PositionObjectTypeDef;

typedef struct
{
	uint8_t id;
	PositionObjectTypeDef position;
}RecognitionHanleTypeDef;


/**
 * @brief wonder mv接口初始化
 */
void wonder_mv_init(void);

/**
 * @brief 颜色识别
 * 
 * @param  color 指向RecognitionHanleTypeDef类型的指针
 */
void wonder_mv_color_recognition(RecognitionHanleTypeDef* color);

/**
 * @brief 人脸识别
 * 
 * @param  face
 */
void wonder_mv_face_detection(RecognitionHanleTypeDef* face);

/**
 * @brief 标签识别
 * 
 * @param  tag
 */
void wonder_mv_tag_detection(RecognitionHanleTypeDef* tag);

/**
 * @brief 物体识别
 * 
 * @param  obj
 */
void wonder_mv_object_detection(RecognitionHanleTypeDef* obj);
#endif
