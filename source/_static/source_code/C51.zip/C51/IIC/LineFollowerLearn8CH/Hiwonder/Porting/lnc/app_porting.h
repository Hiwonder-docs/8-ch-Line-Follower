#ifndef __APP_PORTING_H__
#define __APP_PORTING_H__

/**
 * @file app_porting.h
 * @brief APP����
 * @version 1.0
 * @date 2025-2-25
 *
 * @copyright Copyright (c) 2024 Hiwonder
 *
 */
 
#include "type.h"
#include "global.h"
#include "ringbuffer.h"

#define APP_PACKET_HEADER                  		0x55  /* ͨ��Э��֡ͷ */
#define MAX_APP_READ_BUFFER_LENGTH				  64
#define MAX_APP_RB_BUFFER_LENGTH			 	 256
#define CHASSIS_CONTROL_TIMEOUT					 200

#pragma pack(1)
typedef struct
{	
	uint8_t packet_header[2];
	uint8_t data_len;
	uint8_t cmd;	
	uint8_t buffer[MAX_APP_READ_BUFFER_LENGTH - 4];
}APPPacketObjectTypeDef;
#pragma pack()

typedef struct
{
	
	uint8_t set_id;
	uint8_t servos_count;
	uint16_t set_duty;
	uint16_t running_time;

	uint8_t action_frame_sum;
	uint8_t action_frame_index;
	uint8_t action_group_index;
	uint16_t running_times;
	
	int8_t read_offset[6];
	int8_t set_offset[6];
	
	int16_t set_x;
	int16_t set_y;
	int16_t set_z;
	
	uint8_t return_val[14];
	
	RingBufferHandleTypedef rb;
	
    APPPacketObjectTypeDef packet;
	APPPacketObjectTypeDef	return_packet;
	
	PacketAnalysisStatus packet_status;
	FunctionStatus status;
	
}AppHandleTypeDef;

void app_init(void);
void app_handler(void);
void uart3_send_buffer(uint8_t* buf, uint16_t len);
void stop_app_receive(void);
void start_app_receive(void);
void stop_pc_receive(void);
void start_pc_receive(void);
#endif