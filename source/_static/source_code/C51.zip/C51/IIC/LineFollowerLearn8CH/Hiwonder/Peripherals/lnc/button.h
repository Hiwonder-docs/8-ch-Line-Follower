#ifndef __BUTTON_H__
#define __BUTTON_H__

#include "type.h"

void button_init(void);
uint8_t get_button_state(void);

#endif
