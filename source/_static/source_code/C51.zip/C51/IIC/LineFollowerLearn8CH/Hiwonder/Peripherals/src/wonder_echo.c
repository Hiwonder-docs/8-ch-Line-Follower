#include "wonder_echo.h"
#include "AI8051U_I2C.h"
#include "string.h"


void wonder_echo_init()
{
	i2c_init();
}

int echo_recognition(void)
{
	static uint8_t result = 0;
	
	i2c_read_data(WONDER_ECHO_ADDRESS, ECHO_RESULT_REG, &result, sizeof(result));
	return result;
}

void echo_speak(uint8_t reg, uint8_t speak_id)
{
	uint8_t trans_data[2] = {0};
	trans_data[0] = reg;
	trans_data[1] = speak_id;
	i2c_write_data(WONDER_ECHO_ADDRESS, ECHO_SPEAK_REG, trans_data, sizeof(trans_data));
}
