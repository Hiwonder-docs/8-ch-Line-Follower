#ifndef __STEPPER_STRIP_H__
#define __STEPPER_STRIP_H__

#include "type.h"

#define STEPPER_STRIP_ADDR				0x35
#define MOTOR_STEPS_DRIVER_MODE_REG		0x15
#define MOTOR_AUTO_REPOSITION_REG		0x16
#define MOTOR_STEPS_REG					0x18
#define MOTOR_STEPS_TIME_REG			0x1C

#define SUBDIVISION_NONE				0x00
#define SUBDIVISION_2					0x01
#define SUBDIVISION_4					0x02
#define SUBDIVISION_8					0x03
#define SUBDIVISION_16					0x07

/* 8ϸ�ֶ��µ�����ܲ��� */
#define MAX_DIV_8_STEPS					10400

typedef struct StepperStripHandle StepperStripHandleTypeDef;
struct StepperStripHandle
{
	uint8_t is_reset;
	int32_t steps;
	int32_t remain_steps;
};

void stepper_strip_init(void);
int8_t read_motor_is_reposition(void);
void set_motor_reposition(void);
void set_motor_subdivision(uint8_t num);
void set_motor_move(int32_t step);


#endif