#ifndef __LED_H__
#define __LED_H__

/**
 * @file led.h
 * @author Min
 * @brief LED驱动
 * @version 1.0
 * @date 2024-12-13
 *
 * @copyright Copyright (c) 2024 Hiwonder
 *
 */
#include "type.h"
#include "io_int.h"

#define LED1_PIN 			Pin26
#define LED2_PIN			Pin35
#define LED1_SET 			P26
#define LED2_SET			P35

#define LED_TIMER_PERIOD    20

typedef enum {
    LED_START_NEW_CYCLE = 0,
    LED_WATTING_OFF,
    LED_WATTING_PERIOD_END,
    LED_IDLE 
} LEDStatusTypeDef;

typedef struct {
    uint8_t  id;
	uint16_t times;
    uint32_t ticks_count;	/* 用于记录当前时间 */
	uint32_t ticks_on;
    uint32_t ticks_off;
	
    LEDStatusTypeDef status;

}LEDHandleTypeDef;


/**
 * @brief LED初始化
 */
void leds_init(void);

/**
 * @brief LED常亮
 * 
 * @param  id 1 or 2
 * 
 * @return None
 */
extern void led_on(uint8_t id);

/**
 * @brief LED常灭
 * 
 * @param  id 1 or 2
 * 
 * @return None
 */
void led_off(uint8_t id);

/**
 * @brief LED闪烁
 * 
 * @param  id 			1 or 2
 * @param  ticks_on 	亮起时间
 * @param  ticks_off 	熄灭时间
 * @param  times 		闪烁次数，0为无限闪烁
 *
 * @return None
 */
void led_flash(uint8_t id, uint32_t ticks_on, uint32_t ticks_off, uint16_t times);

/**
 * @brief LED句柄 定时20ms调用
 */
void leds_handler(void);

#endif
