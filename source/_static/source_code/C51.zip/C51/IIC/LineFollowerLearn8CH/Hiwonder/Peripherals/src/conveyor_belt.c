#include "conveyor_belt.h"
#include "AI8051U_I2C.h"
#include "string.h"

void conveyor_belt_init()
{
	i2c_init();
}

void set_conveyor_belt_speed(int8_t speed)
{
	uint8_t _speed = speed;
	i2c_write_data(CONVEYORBELT_ADDR << 1, 0, &_speed, 1);
}