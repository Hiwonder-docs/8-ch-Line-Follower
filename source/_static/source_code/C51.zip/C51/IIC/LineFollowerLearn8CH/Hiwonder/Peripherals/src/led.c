#include "led.h"
#include "string.h"
#include "set_io.h"

LEDHandleTypeDef led1;
LEDHandleTypeDef led2;

static void led_handler(LEDHandleTypeDef *self)
{
    switch(self->status)
	{
        case LED_START_NEW_CYCLE:
            if(self->ticks_on > 0)
			{
				switch(self->id)
				{
					case 1:
						LED1_SET = 0;
						break;
					
					case 2:
						LED2_SET = 1;
						break;
				}
                if(self->ticks_off > 0)
				{ /* Ϩ��ʱ�䲻Ϊ 0 ��Ϊ ��˸����Ϊ���� */
                    self->ticks_count = 0;
                    self->status = LED_WATTING_OFF; /* �ȴ� LED ������ʱ����� */
                }
				else
				{
					self->status = LED_IDLE; /* ������ ת����� */
				}
            }
			else
			{ /* ֻҪ����ʱ��Ϊ 0 ��Ϊ���� */
				switch(self->id)
				{
					case 1:
						LED1_SET = 1;
						break;
					
					case 2:
						LED2_SET = 0;
						break;
				}
				self->status = LED_IDLE; /* ���� ת����� */
            }
            break;
			
        case LED_WATTING_OFF:
            self->ticks_count += LED_TIMER_PERIOD;
            if(self->ticks_count >= self->ticks_on)
			{ /* LED ����ʱ����� */
				switch(self->id)
				{
					case 1:
						LED1_SET = 1;
						break;
					
					case 2:
						LED2_SET = 0;
						break;
				}
                self->status = LED_WATTING_PERIOD_END;
            }
            break;

        case LED_WATTING_PERIOD_END:	/* �ȴ����ڽ��� */
            self->ticks_count += LED_TIMER_PERIOD;
            if(self->ticks_count >= (self->ticks_off + self->ticks_on))
			{
				self->ticks_count -= (self->ticks_off + self->ticks_on);
                if(self->times == 1)
				{ /* ʣ���ظ�����Ϊ1ʱ�Ϳ��Խ����˴ο������� */
					switch(self->id)
					{
						case 1:
							LED1_SET = 1;
							break;
						
						case 2:
							LED2_SET = 0;
							break;
					}
                    self->status = LED_IDLE;  /* �ظ��������꣬ ת����� */
                }
				else
				{
					switch(self->id)
					{
						case 1:
							LED1_SET = 0;
							break;
						
						case 2:
							LED2_SET = 1;
							break;
					}
                    self->times = self->times == 0 ? 0 : self->times - 1;
                    self->status = LED_WATTING_OFF;
                }
            }
            break;

        case LED_IDLE:
            break;
		
        default:
            break;
    }
}


void leds_init()
{
	memset(&led1, 0, sizeof(LEDHandleTypeDef));
	memset(&led2, 0, sizeof(LEDHandleTypeDef));
	
	led1.id = 1;
	P2M0 |= 0x40;
	P2M1 &= ~0x40; 
    P2SR &= ~0x40; 
	LED1_SET = 1;
	
	led2.id = 2;
	P3M0 |= 0x20; 
	P3M1 &= ~0x20; 
	P3SR &= ~0x20; 
	LED2_SET = 0;
}

void led_on(uint8_t id)
{
	switch(id)
	{
		case 1:
			led1.ticks_on = 1;
			led1.ticks_off = 0;
			led1.times = 0;
			led1.status = LED_START_NEW_CYCLE;
			break;
		
		case 2:
			led2.ticks_on = 1;
			led2.ticks_off = 0;
			led2.times = 0;
			led2.status = LED_START_NEW_CYCLE;
			break;
		
		default:
			break;
	}
	
}

void led_off(uint8_t id)
{
	switch(id)
	{
		case 1:
			led1.ticks_on = 0;
			led1.ticks_off = 0;
			led1.times = 0;
			led1.status = LED_START_NEW_CYCLE;
			break;
		
		case 2:
			led2.ticks_on = 0;
			led2.ticks_off = 0;
			led2.times = 0;
			led2.status = LED_START_NEW_CYCLE;
			break;
		
		default:
			break;
	}
}

void led_flash(uint8_t id, uint32_t ticks_on, uint32_t ticks_off, uint16_t times)
{
	switch(id)
	{
		case 1:
			led1.ticks_on = ticks_on;
			led1.ticks_off = ticks_off;
			led1.times = times;
			led1.status = LED_START_NEW_CYCLE;
			break;
		
		case 2:
			led2.ticks_on = ticks_on;
			led2.ticks_off = ticks_off;
			led2.times = times;
			led2.status = LED_START_NEW_CYCLE;
			break;
		
		default:
			break;
	}
}


void leds_handler()
{
	led_handler(&led1);
	led_handler(&led2);
}

