#ifndef __RINGBUFFER_H__
#define __RINGBUFFER_H__

#include "type.h"

#define BUF_IS_VALID(b) ((b) != NULL && (b)->buf != NULL && (b)->len > 0)
#define BUF_MIN(x, y)   ((x) < (y) ? (x) : (y))

typedef struct
{
	uint8_t* buf;
	uint32_t len;
	uint32_t w_ptr;
	uint32_t r_ptr;
	uint32_t write_len;
	uint32_t read_len;
	
}RingBufferHandleTypedef;

extern uint8_t rb_init(RingBufferHandleTypedef* self, uint8_t* buffdata, uint32_t bufflen) reentrant;
extern uint32_t rb_getfree(const RingBufferHandleTypedef* self) reentrant;
extern uint32_t rb_getfull(const RingBufferHandleTypedef* self) reentrant;
extern uint32_t rb_write(RingBufferHandleTypedef* self, uint8_t* buf, uint32_t btw) reentrant;
extern uint32_t rb_read(RingBufferHandleTypedef* self, uint8_t* buf, uint32_t btr) reentrant;

#endif