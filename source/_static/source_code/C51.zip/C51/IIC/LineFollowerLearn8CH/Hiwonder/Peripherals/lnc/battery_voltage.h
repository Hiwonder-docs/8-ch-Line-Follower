#ifndef __BATTERY_VOLTAGE_H__
#define __BATTERY_VOLTAGE_H__

#include "AI8051U_ADC.h"

void bat_voltage_init(void);
float get_bat_voltage(void);

#endif
