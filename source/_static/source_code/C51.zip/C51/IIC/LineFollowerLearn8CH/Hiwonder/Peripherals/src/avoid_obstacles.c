#include "avoid_obstacles.h"
#include "AI8051U.h"

void avoid_obstacles_init(void)
{
    P0M0 &= ~0x10; 
	P0M1 |= 0x10; 
	
    P1M0 &= ~0x02; 
	P1M1 |= 0x02; 
}

uint8_t get_avoid_obstacle1_state(void)
{
	uint8_t state;
	state = (P0 & 0x10) >> 4;
	return state;
}

uint8_t get_avoid_obstacle2_state(void)
{
	uint8_t state;
	state = (P1 & 0x02) >> 1;
	return state;
}