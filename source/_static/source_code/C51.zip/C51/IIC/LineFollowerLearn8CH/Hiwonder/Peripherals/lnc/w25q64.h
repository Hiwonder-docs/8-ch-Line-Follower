#ifndef __W25Q64_H__
#define __W25Q64_H__

/* 
 * SPI CS���� P05
 * MOSI P15
 * MISO P16
 * SCLK P17
 */

/**
 * @file w25q64.h
 * @author Min
 * @brief ����flash��д
 * @version 1.0
 * @date 2025-02-17
 *
 * @copyright Copyright (c) 2025 Hiwonder
 *
 */
 
#include "type.h"
#include "AI8051U.h"

#define W25X_CS_SET				P05

/* W25Q64?�洢оƬ ָ��� */
#define W25X_WriteEnable		0x06
#define W25X_WriteDisable		0x04
#define W25X_ReadStatusReg		0x05
#define W25X_WriteStatusReg		0x01
#define W25X_ReadData			0x03
#define W25X_PageProgram		0x02
#define W25X_SectorErase		0x20
#define W25X_DeviceID			0xAB
#define W25X_ManufactDeviceID	0x90
#define W25X_UniqueID			0x4B

void w25q64_init(void);
void w25q64_erase_sector(uint32_t addr);
void w25q64_read(uint32_t addr, uint8_t* buffer, uint32_t len);
void w25q64_write(uint32_t addr, const uint8_t* buffer, uint32_t len);
void w25q64_read_manufact_device_id(uint32_t* id);
void w25q64_read_unique_id(uint32_t* id_h, uint32_t* id_l);
#endif
