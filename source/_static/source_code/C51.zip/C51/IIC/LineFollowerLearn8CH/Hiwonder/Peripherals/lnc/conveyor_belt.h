#ifndef __CONVEYOR_BELT_H__
#define __CONVEYOR_BELT_H__

#include "type.h"

#define CONVEYORBELT_ADDR	0x37

void conveyor_belt_init(void);
void set_conveyor_belt_speed(int8_t speed);
	
#endif
