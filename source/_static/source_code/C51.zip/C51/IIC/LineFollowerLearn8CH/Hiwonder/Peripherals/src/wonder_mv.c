#include "wonder_mv.h"
#include "string.h"
#include "global.h"
#include "AI8051U_I2C.h"

void wonder_mv_init()
{
	i2c_init();
}

void wonder_mv_color_recognition(RecognitionHanleTypeDef* color)
{
	static uint8_t results[9];

	/*
	 * [0]:id
	 * [1]:x(low 8bit) 
	 * [2]:x(high 8bit) 
	 * [3]:y(low 8bit) 
	 * [4]:y(high 8bit) 
	 * [5]:w(low 8bit) 
	 * [6]:w(high 8bit) 
	 * [7]:w(low 8bit) 
	 * [8]:w(high 8bit)
	 */
	i2c_read_data(WONDERMV_ADDR << 1, COLOR_REG, results, sizeof(results));
	color->id = results[0];
	color->position.x = BYTE_TO_HW(results[2], results[1]);
	color->position.y = BYTE_TO_HW(results[4], results[3]);
	color->position.w = BYTE_TO_HW(results[6], results[5]);
	color->position.h = BYTE_TO_HW(results[8], results[7]);
}


void wonder_mv_face_detection(RecognitionHanleTypeDef* face)
{
	static uint8_t results[9];
	/* 
	 * [0]:x(low 8bit) 
	 * [1]:x(high 8bit) 
	 * [2]:y(low 8bit) 
	 * [3]:y(high 8bit) 
	 * [4]:w(low 8bit) 
	 * [5]:w(high 8bit) 
	 * [6]:w(low 8bit) 
	 * [7]:w(high 8bit)
	 */
	i2c_read_data(WONDERMV_ADDR << 1, FACE_REG, results, sizeof(results));
	face->id = results[0];
	face->position.x = BYTE_TO_HW(results[2], results[1]);
	face->position.y = BYTE_TO_HW(results[4], results[3]);
	face->position.w = BYTE_TO_HW(results[6], results[5]);
	face->position.h = BYTE_TO_HW(results[8], results[7]);
}

	
void wonder_mv_tag_detection(RecognitionHanleTypeDef* tag)
{
	static uint8_t results[9];
	
	i2c_read_data(WONDERMV_ADDR << 1, TAG_REG, results, sizeof(results));
	tag->id = results[0];
	tag->position.x = BYTE_TO_HW(results[2], results[1]);
	tag->position.y = BYTE_TO_HW(results[4], results[3]);
	tag->position.w = BYTE_TO_HW(results[6], results[5]);
	tag->position.h = BYTE_TO_HW(results[8], results[7]);
}

void wonder_mv_object_detection(RecognitionHanleTypeDef* obj)
{
	static uint8_t results[9];
	
	i2c_read_data(WONDERMV_ADDR << 1, OBJECT_REG, results, sizeof(results));
	obj->id = results[0];
	obj->position.x = BYTE_TO_HW(results[2], results[1]);
	obj->position.y = BYTE_TO_HW(results[4], results[3]);
	obj->position.w = BYTE_TO_HW(results[6], results[5]);
	obj->position.h = BYTE_TO_HW(results[8], results[7]);
}
