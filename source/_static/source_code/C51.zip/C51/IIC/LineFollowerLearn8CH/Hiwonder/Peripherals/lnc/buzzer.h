#ifndef __BUZZER_H__
#define __BUZZER_H__

#include "type.h"

#define BUZZER_FREQ 		   4000	/* ��λ��Hz */

#define BUZZER_TIMER_PERIOD    20

typedef enum
{
    BUZZER_START_NEW_CYCLE = 0,
    BUZZER_WATTING_OFF,
    BUZZER_WATTING_PERIOD_END,
    BUZZER_IDLE
} BuzzerStatusTypeDef;

typedef struct
{
	uint16_t times;
    uint32_t ticks_count;	/* ���ڼ�¼��ǰʱ�� */
	uint32_t ticks_on;
    uint32_t ticks_off;
	
    BuzzerStatusTypeDef status;

}BuzzerHandleTypeDef;

void buzzer_init(void);
void buzzer_on(void);
void buzzer_off(void);
void buzzer_toggle(uint32_t ticks_on, uint32_t ticks_off, uint16_t times);
void buzzer_handler(void);

#endif
