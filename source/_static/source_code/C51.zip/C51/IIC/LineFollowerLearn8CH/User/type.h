#ifndef __TYPE_H__
#define __TYPE_H__
/*-----------------------------------------------------------------------
|                                 DATA                                  |
-----------------------------------------------------------------------*/
/*
 * If there is a conflict between the redefinition of RTOS and this, 
 * you can call the redefinition header file of RTO to replace it, 
 * or add this header file to RTOS and comment out the conflict.
**/

/*--------------------------------------------------------
| @Description: Exact width signed integer types         |
--------------------------------------------------------*/
						
typedef  signed char  int8_t;	//  8 bits 
typedef  signed int  int16_t;	// 16 bits 
typedef  signed long int32_t;	// 32 bits 
						
typedef  signed char  int8;	//  8 bits 
typedef  signed int  int16;	// 16 bits 
typedef  signed long int32;	// 32 bits

/*--------------------------------------------------------
| @Description: Volatile width signed integer types      |
--------------------------------------------------------*/

typedef  volatile int8_t    vint8_t; //  8 bits 
typedef  volatile int16_t  vint16_t; // 16 bits 
typedef  volatile int32_t  vint32_t; // 32 bits 

typedef  volatile int8_t    vint8; //  8 bits 
typedef  volatile int16_t  vint16; // 16 bits 
typedef  volatile int32_t  vint32; // 32 bits 

/*--------------------------------------------------------
| @Description: Exact width unsigned integer types       |
--------------------------------------------------------*/

typedef  unsigned char   uint8_t; //  8 bits 
typedef  unsigned int   uint16_t; // 16 bits 
typedef  unsigned long  uint32_t; // 32 bits 

typedef  unsigned char   u8; //  8 bits 
typedef  unsigned int   u16; // 16 bits 
typedef  unsigned long  u32; // 32 bits 

typedef  unsigned char   uint8; //  8 bits 
typedef  unsigned int   uint16; // 16 bits 
typedef  unsigned long  uint32; // 32 bits 

/*--------------------------------------------------------
| @Description: Volatile width unsigned integer types    |
--------------------------------------------------------*/

typedef  volatile uint8_t    vuint8_t; //  8 bits 
typedef  volatile uint16_t  vuint16_t; // 16 bits 
typedef  volatile uint32_t  vuint32_t; // 32 bits 

typedef  volatile uint8_t    vu8; //  8 bits 
typedef  volatile uint16_t  vu16; // 16 bits 
typedef  volatile uint32_t  vu32; // 32 bits 

typedef  volatile uint8_t    vuint8; //  8 bits 
typedef  volatile uint16_t  vuint16; // 16 bits 
typedef  volatile uint32_t  vuint32; // 32 bits 

#endif