// <<< Use Configuration Wizard in Context Menu >>>
#ifndef __GLOBAL_H__
#define __GLOBAL_H__

#include "type.h"

/* ϵͳʱ������Ϊ40MHz */
#define MAIN_Fosc 40000000UL

/* �꺯�� ���A�ĵͰ�λ */
#define GET_LOW_BYTE(A) ((uint8_t)(A))
/* �꺯�� ���A�ĸ߰�λ */
#define GET_HIGH_BYTE(A) ((uint8_t)((A) >> 8))
/* �꺯�� ���ߵذ�λ�ϳ�Ϊʮ��λ */
#define BYTE_TO_HW(A, B) ((((uint16_t)(A)) << 8) | (uint8_t)(B))

/* ��λ��ms */
#define LED_HANDLER_PERIOD       	LED_TIMER_PERIOD
#define PWM_SERVOS_HANDLER_PERIOD	MIN_RUNNING_TIME
#define BUTTON_HANDLER_PERIOD    	20
#define BUZZER_HANDLER_PERIOD       25
#define SOFTWARE_VERSION			1

/* ��������(15,0,2) */
#define PWM_SERVO1_RESET_DUTY 			   			  770
#define PWM_SERVO2_RESET_DUTY 			  			 1500
#define PWM_SERVO3_RESET_DUTY 			   			  640
#define PWM_SERVO4_RESET_DUTY 			   			  511
#define PWM_SERVO5_RESET_DUTY 			  			 1255
#define PWM_SERVO6_RESET_DUTY 			  			 1500

#define SERIAL_SERVO1_RESET_DUTY		   			  226
#define SERIAL_SERVO2_RESET_DUTY		   			  500 
#define SERIAL_SERVO3_RESET_DUTY		   			  177 
#define SERIAL_SERVO4_RESET_DUTY		   			  129 
#define SERIAL_SERVO5_RESET_DUTY		   			  408 
#define SERIAL_SERVO6_RESET_DUTY		   			  500 


// <o>Arm Type
//  <i>Select servo type
//  <0=> PWM Servos Arm
//  <1=> Serial Servos Arm
#define ARM_SELECT				0
#if (ARM_SELECT == 0)
	#define SERVO_TYPE			1
#elif (ARM_SELECT == 1)
	#define SERVO_TYPE			2
#endif

#if (SERVO_TYPE == 1)
	#define PS2_SET_MAX_DUTY							 2500
	#define PS2_SET_MIN_DUTY							  500
#elif (SERVO_TYPE == 2)
	#define PS2_SET_MAX_DUTY							  875
	#define PS2_SET_MIN_DUTY							  125
#endif

// <o>Chassis Select
//  <i>Select chassis type
//  <0=> None
//  <1=> Mecanum Chassis
//  <2=> Differential Chassis
#define CHASSIS_SELECT				0
#if (CHASSIS_SELECT == 1)
	#define MECANUM_CHASSIS
#elif (CHASSIS_SELECT == 2)
	#define DIFFERENTIAL_CHASSIS
#endif

typedef enum
{
	PACKET_HEADER_1 = 0,
	PACKET_HEADER_2,
	PACKET_DATA_LENGTH,
	PACKET_FUNCTION,
	PACKET_DATA
}PacketAnalysisStatus;

typedef enum
{
	CMD_VERSION_QUERY = 1,
	CMD_SERVO_OFFSET_READ,
	CMD_MULT_SERVO_MOVE,
	CMD_COORDINATE_SET = 4,
	CMD_ACTION_GROUP_RUN = 6,
	CMD_FULL_ACTION_STOP,
	CMD_FULL_ACTION_ERASE,
	CMD_CHASSIS_CONTROL,
	CMD_SERVO_OFFSET_SET,	
	CMD_SERVO_OFFSET_DOWNLOAD,
	CMD_SERVOS_RESET,
	CMD_ANGLE_BACK_READING,
	CMD_ACTION_DOWNLOAD = 25,
	CMD_FUNC_NULL
}FunctionStatus;

extern uint8_t arm_select;
uint32_t get_tick();

#endif
// <<< end of configuration section >>>